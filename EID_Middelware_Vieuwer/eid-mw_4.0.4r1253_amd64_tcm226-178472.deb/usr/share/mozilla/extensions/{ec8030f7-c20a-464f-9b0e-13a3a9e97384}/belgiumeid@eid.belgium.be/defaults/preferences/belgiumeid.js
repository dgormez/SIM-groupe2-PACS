pref("extensions.belgiumeid.modulename", "Belgium eID PKCS#11 Module");

pref("extensions.belgiumeid.modulelocation", "beidpkcs11.dll;libbeidpkcs11.so.0;libbeidpkcs11.so;/Library/Frameworks/BeId.framework/Versions/4.0/lib/libbeidpkcs11.dylib;/usr/local/lib/beid-pkcs11.bundle;/usr/local/lib/beid-pkcs11.bundle/Contents/MacOS/libbeidpkcs11.dylib;/usr/local/lib/libbeidpkcs11.so");
pref("extensions.belgiumeid.showmodulenotfoundnotification", true);
